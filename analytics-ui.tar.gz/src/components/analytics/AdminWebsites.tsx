"use client";

import { useMemo, useState } from "react";

type Website = {
  id: string;
  name: string;
  allowedDomains: string[];
  createdAt: string;
};

const hostUrl =
  process.env.NEXT_PUBLIC_HOST_URL ?? "https://analytics.gundemhane.com";

const snippetFor = (websiteId: string) => `<script async src="${hostUrl}/tracker.js"
  data-website-id="${websiteId}"
  data-host-url="${hostUrl}">
</script>`;

export default function AdminWebsites({
  initialWebsites,
}: {
  initialWebsites: Website[];
}) {
  const [websites, setWebsites] = useState(
    initialWebsites.map((site) => ({
      ...site,
      draftName: site.name,
      draftDomains: site.allowedDomains.join(", "),
    }))
  );
  const [creating, setCreating] = useState(false);
  const [newName, setNewName] = useState("");
  const [newDomains, setNewDomains] = useState("");
  const [error, setError] = useState<string | null>(null);

  const sortedWebsites = useMemo(
    () =>
      [...websites].sort(
        (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      ),
    [websites]
  );

  const refreshWebsite = (updated: Website) => {
    setWebsites((prev) =>
      prev.map((site) =>
        site.id === updated.id
          ? {
              ...updated,
              draftName: updated.name,
              draftDomains: updated.allowedDomains.join(", "),
            }
          : site
      )
    );
  };

  const handleCreate = async () => {
    setCreating(true);
    setError(null);
    try {
      const response = await fetch("/api/analytics/admin/websites", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: newName,
          allowedDomains: newDomains,
        }),
      });

      const payload = await response.json();
      if (!response.ok) {
        throw new Error(payload.error ?? "Failed to create website.");
      }

      setWebsites((prev) => [
        {
          ...payload.website,
          createdAt: payload.website.createdAt,
          draftName: payload.website.name,
          draftDomains: payload.website.allowedDomains.join(", "),
        },
        ...prev,
      ]);
      setNewName("");
      setNewDomains("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to create website.");
    } finally {
      setCreating(false);
    }
  };

  const handleUpdate = async (id: string, name: string, domains: string) => {
    setError(null);
    const response = await fetch(`/api/analytics/admin/websites/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, allowedDomains: domains }),
    });
    const payload = await response.json();
    if (!response.ok) {
      setError(payload.error ?? "Failed to update website.");
      return;
    }
    refreshWebsite(payload.website);
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Delete this website? This will remove all analytics data.")) {
      return;
    }
    setError(null);
    const response = await fetch(`/api/analytics/admin/websites/${id}`, {
      method: "DELETE",
    });
    if (!response.ok) {
      const payload = await response.json();
      setError(payload.error ?? "Failed to delete website.");
      return;
    }
    setWebsites((prev) => prev.filter((site) => site.id !== id));
  };

  const copySnippet = async (websiteId: string) => {
    await navigator.clipboard.writeText(snippetFor(websiteId));
  };

  return (
    <section className="space-y-6">
      <header className="space-y-1">
        <h2 className="text-xl font-semibold text-slate-900">Websites</h2>
        <p className="text-sm text-slate-500">
          Create tracking properties and manage allowed domains.
        </p>
      </header>

      <div className="grid gap-4 rounded-2xl border border-slate-200 bg-white p-6 shadow-sm">
        <div className="grid gap-3 md:grid-cols-[1fr_2fr_auto]">
          <input
            className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
            placeholder="Website name"
            value={newName}
            onChange={(event) => setNewName(event.target.value)}
          />
          <input
            className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
            placeholder="Allowed domains (comma separated)"
            value={newDomains}
            onChange={(event) => setNewDomains(event.target.value)}
          />
          <button
            type="button"
            onClick={handleCreate}
            disabled={creating}
            className="rounded-lg bg-slate-900 px-4 py-2 text-sm font-medium text-white disabled:opacity-60"
          >
            {creating ? "Creating..." : "Add website"}
          </button>
        </div>
        {error ? (
          <div className="rounded-lg border border-rose-200 bg-rose-50 px-3 py-2 text-xs text-rose-700">
            {error}
          </div>
        ) : null}
      </div>

      <div className="space-y-4">
        {sortedWebsites.map((site) => (
          <div
            key={site.id}
            className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm"
          >
            <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
              <div>
                <h3 className="text-lg font-semibold text-slate-900">
                  {site.name}
                </h3>
                <p className="text-xs text-slate-500">{site.id}</p>
              </div>
              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  className="rounded-lg border border-slate-200 px-3 py-2 text-xs font-medium text-slate-700"
                  onClick={() => copySnippet(site.id)}
                >
                  Copy snippet
                </button>
                <button
                  type="button"
                  className="rounded-lg border border-rose-200 px-3 py-2 text-xs font-medium text-rose-600"
                  onClick={() => handleDelete(site.id)}
                >
                  Delete
                </button>
              </div>
            </div>
            <div className="mt-4 grid gap-3 md:grid-cols-[1fr_2fr_auto]">
              <input
                className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
                value={site.draftName}
                onChange={(event) =>
                  setWebsites((prev) =>
                    prev.map((entry) =>
                      entry.id === site.id
                        ? { ...entry, draftName: event.target.value }
                        : entry
                    )
                  )
                }
              />
              <input
                className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
                value={site.draftDomains}
                onChange={(event) =>
                  setWebsites((prev) =>
                    prev.map((entry) =>
                      entry.id === site.id
                        ? { ...entry, draftDomains: event.target.value }
                        : entry
                    )
                  )
                }
              />
              <button
                type="button"
                className="rounded-lg bg-slate-900 px-4 py-2 text-sm font-medium text-white"
                onClick={() => handleUpdate(site.id, site.draftName, site.draftDomains)}
              >
                Save
              </button>
            </div>
            <div className="mt-4 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-mono text-slate-700">
              {snippetFor(site.id)}
            </div>
          </div>
        ))}
        {sortedWebsites.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-slate-200 bg-white p-8 text-center text-sm text-slate-500">
            No websites yet.
          </div>
        ) : null}
      </div>
    </section>
  );
}
